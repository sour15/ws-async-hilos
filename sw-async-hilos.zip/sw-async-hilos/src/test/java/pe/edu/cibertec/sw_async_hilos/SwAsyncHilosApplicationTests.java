package pe.edu.cibertec.sw_async_hilos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwAsyncHilosApplicationTests {

	@Test
	void contextLoads() {
	}

}
